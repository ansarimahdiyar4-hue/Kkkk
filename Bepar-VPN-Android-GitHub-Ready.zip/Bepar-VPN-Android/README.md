# Bepar VPN 2.0 — Android (Connect-Ready)

Full Jetpack Compose client with real `VpnService` + **sing-box libbox 1.14.0** included.

```bash
./gradlew assembleDebug
```

Install the APK, grant VPN permission, tap Connect.

- Default servers: public morpheus feed (live)
- Native core: `app/libs/libbox.aar` (all ABIs)
- Docs (Persian): `README_FA.md`, `BUILD-AND-CORE.md`, `docs/PORT-STATUS-REPORT-FA.md`
