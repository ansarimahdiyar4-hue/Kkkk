# جدول تطبیق کامل UI اصلی Bepar VPN با Jetpack Compose

| شناسه / صفحه در `02_ORIGINAL_FRONTEND` | شرح و اجزای اصلی | Composable متناظر در Android (`com.bepar.vpn`) | نکات انیمیشن و تفاوت پلتفرمی |
|---|---|---|---|
| `#splash` + `#splash-warning` | لوگوی دایره‌ای، حلقه چرخان 1.43s، هشدار امنیتی و راهنمای حذف | `SplashScreen` (`SplashAndSecurityScreens.kt`) | چرخش پیوسته `infiniteRepeatable(tween(1430))`؛ در Reduced Motion ثابت می‌شود |
| `#lock-screen` | قفل تمام‌صفحه امنیتی هنگام کشف ابزار شنود/دیباگر | `RuntimeSecurityLockScreen` (`SplashAndSecurityScreens.kt`) | پس‌زمینه `#000000`، دکمه‌های Close و Check again |
| `#lang-screen` | انتخاب زبان اولیه (فارسی با `ir.svg` و انگلیسی با `gb.svg`) | `FirstLaunchLanguageScreen` (`OnboardingScreens.kt`) | پرچم‌های واقعی SVG با `SvgFlagImage` (بدون ایموجی) |
| `#terms-screen` | متن کامل ۹ بند قوانین و حریم خصوصی + Checkbox + Decline/Continue | `TermsScreen` (`OnboardingScreens.kt`) | دکمه Continue تا تیک‌زدن چک‌باکس غیرفعال است |
| `#onboarding` (3 گام) | انتخاب منبع `Config Peer 1..7`، انتخاب حالت Auto/Manual، صفحه بارگذاری/خطا با Retry | `OnboardingWizardScreen` (`OnboardingScreens.kt`) | نام منابع واقعی همواره به `Config Peer 1..7` / `کانفیگ بپر ۱..۷` ماسک می‌شوند |
| `#page-home` | انتخاب‌گر سرور، بنر وضعیت، `OrthographicGlobe`، دکمه Power مرکزی، وضعیت، Delay، کارت اتصال و تلگرام | `HomeScreen` (`HomeScreen.kt`) + `OrthographicGlobe` | کره با سرعت 1.1°/s (قطع) و 7.5°/s (پیش‌نمایش متصل)؛ بنر صادقانه `Preview / Not connected` |
| `#sheet-backdrop` + `#server-sheet` | پنجره کشویی سرورها، `Test All Ping`، جست‌وجو، `Automatic`، گروه‌بندی کشور، ردیف سرور و چیپ پینگ | `ServerSelectionSheet` (`ServerSheet.kt`) | `ModalBottomSheet` با مرتب‌سازی عددی-طبیعی و جست‌وجوی چندفیلدی |
| `#dock` + `#snackbar` | نوار شناور شیشه‌ای پایین (Settings, Home, About) و پیامک‌های 2.5 ثانیه‌ای | `FloatingDock` + `BeparSnackbarOverlay` (`FloatingDock.kt`) | شفافیت شیشه‌ای + حاشیه `navBarsPadding` |
| `#page-settings` | بروزرسانی سرور، منبع کانفیگ، امنیت، ظاهر، زبان، DNS، TUN Mode | `SettingsRootScreen` (`SettingsScreens.kt`) | افزودن تاگل Reduced Motion و سوئیچ UI Layout Preview |
| `#sub-sources` | فهرست ۷ منبع کانفیگ با توضیحات فارسی/انگلیسی | `ConfigSourceSubScreen` (`SettingsScreens.kt`) | از `SourceDisplayRegistry` تغذیه می‌شود |
| `#sub-security` | رمزنگاری اجباری، کش، یکپارچگی، آپدیت، Log/Clipboard/Leak switches | `SecuritySubScreen` (`SettingsScreens.kt`) | بخش DPAPI ویندوز با Android Keystore + AEAD جایگزین مستند شد |
| `#sub-theme` | انتخاب تم Black/White + نوار گرادیان طیف رنگ + دو نقطه سفید/سیاه + کد Hex | `AppearanceSubScreen` (`SettingsScreens.kt`) | محاسبه کنتراست خودکار `accentInk` و `accentOn` مطابق `app.js` |
| `#sub-language` | انتخاب English / فارسی | `LanguageSubScreen` (`SettingsScreens.kt`) | تغییر فونت بین `Inter` و `Estedad` + `LayoutDirection` RTL/LTR |
| `#sub-dns` | System / Cloudflare / Google / Quad9 / Custom + اعتبارسنجی ورودی | `DnsSubScreen` (`SettingsScreens.kt`) | Regex دقیق IPv4 / IPv6 / `https://` مطابق `app.js` |
| `#page-about` | لوگو، نسخه `2.0.0`، ۳ نشان، توضیحات، ۳ کارت اطلاعات، کپی `@Bepar_VPN`، کپی‌رایت 2026 | `AboutScreen` (`AboutScreen.kt`) | کلیپ‌بورد امن با پاک‌سازی خودکار پس از ۳۰ ثانیه |
