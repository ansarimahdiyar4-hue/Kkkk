# رجیستری کامل دارایی‌های گرافیکی Bepar VPN (Android Port)

تمام دارایی‌های گرافیکی، فونت‌ها و نقشه جغرافیایی مستقیماً از `02_ORIGINAL_FRONTEND` بدون تبدیل افت‌کیفیت و بدون جایگزینی با ایموجی مصرف شده‌اند.

| دسته | مسیر مبدأ در `02_ORIGINAL_FRONTEND` | مسیر مقصد در `01_ANDROID_PROJECT` | تعداد / مشخصات | نحوه مصرف در Compose |
|---|---|---|---|---|
| لوگوی اصلی | `bepar.png` | `app/src/main/res/drawable-nodpi/bepar_logo.png` | 1 فایل PNG | `painterResource(R.drawable.bepar_logo)` در Splash، Language، Terms، Onboarding، About و آیکن برنامه |
| آیکن تلگرام | `telegram.png` | `app/src/main/res/drawable-nodpi/telegram_logo.png` | 1 فایل PNG | `painterResource(R.drawable.telegram_logo)` در Home CTA و About Card |
| پرچم کشورها | `flags/*.svg` | `app/src/main/assets/flags/*.svg` | 257 فایل SVG | `SvgFlagImage` با `coil-kt:coil-svg` (`file:///android_asset/flags/{cc}.svg`) |
| نقشه جهان (1-degree mask) | `worldmask.js` (`__BEPAR_LANDMASK`) | `app/src/main/assets/worldmask.txt` | ماسک 360×180 بیتی (Base64، 10,800 بایت متن) | `WorldMaskLoader` + `OrthographicGlobe` Canvas |
| فونت فارسی | `android-static-ttf/Estedad-Variable-{400,500,600,700}.ttf` | `app/src/main/res/font/estedad_{400,500,600,700}.ttf` | 4 وزن استاتیک SIL OFL 1.1 | `EstedadFontFamily` در `Theme.kt` |
| فونت انگلیسی/لاتین | `android-static-ttf/Inter-Variable-latin-{400,500,600,700}.ttf` | `app/src/main/res/font/inter_{400,500,600,700}.ttf` | 4 وزن استاتیک SIL OFL 1.1 | `InterFontFamily` در `Theme.kt` |
| مجوز و اعلان‌ها | `LICENSE`, `NOTICE` | `assets/extracted/LICENSE-Bepar.txt`, `NOTICE-Bepar.txt` | 2 فایل متنی | نگهداری‌شده مطابق شرایط منبع |
