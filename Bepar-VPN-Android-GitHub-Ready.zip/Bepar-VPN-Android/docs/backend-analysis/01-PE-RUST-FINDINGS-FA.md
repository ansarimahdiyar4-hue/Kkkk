# نتایج تحلیل PE و Rust باینری Bepar VPN

## هویت اجرایی

- فایل: `Bepar VPN.exe`
- SHA-256: `ec8d750ba162d847d3ebd4f99d68b9f1ce576f2437e6432ffbcea960a1b1d36f`
- قالب: PE32+ / x86-64، Windows GUI، image base `0x140000000`.
- timestamp گزارش PE: 2026-11-07 06:33:48 (مقدار PE؛ ساعت build الزاماً زمان انتشار نیست).
- 6 section اصلی: `.text`, `.rdata`, `.data`, `.pdata`, `.rsrc`, `.reloc`.
- `.pdata` دارای 8,077 رکورد 12-byte از نوع x64 `RUNTIME_FUNCTION` است؛ index آدرس‌ها در `x64-unwind-function-ranges.csv` قرار دارد. این رکوردها نام تابع/کد source نمی‌دهند.
- یک disassembly کامل address-oriented با Intel syntax در `disassembly-rust-exe-intel.txt` نگهداری شده؛ به دلیل نبود symbolها صرفاً machine instructions و آدرس را نشان می‌دهد.
- CLR header ندارد؛ پس .NET نیست. مسیرهای crate و `w_vpn::...`، Rust native بودن را نشان می‌دهند.
- Tauri 2.12.1 / Wry 0.57.0 و WebView2 مشاهده شده‌اند.
- Bundle identifier: `com.soheil.kiarsyan.wvpn`; product version string: `2.0.0`.

## Debug/PDB

Debug Directory از نوع CodeView / RSDS به فایل خارجی `bepar_vpn.pdb` اشاره می‌کند.

- GUID: `cd2582cbd81e4e4883b161605cf6cea1`
- Age: `1`
- فایل PDB داخل ZIP ورودی نبود.
- جدول symbolهای COFF در فایل قابل استفاده برای بازیابی نام توابع یافت نشد.

حتی با PDB منطبق نیز متن سورس Rust بازیابی نمی‌شود؛ PDB می‌تواند symbol، نوع‌ها، خط/مسیرهای debug و mappingهای بیشتری ارائه کند. سورس اصلی باید از Git/دستگاه build/نسخه پشتیبان تهیه شود.

## مسیرهای ماژول‌های متعلق به اپ

مسیرهای source که به‌صورت رشته در باینری دیده شده‌اند:

- `src/commands.rs`
- `src/geoip.rs`
- `src/source.rs`
- `src/tester.rs`
- `src/xraycfg.rs`
- `src/intercept.rs`
- `src/pool.rs`
- `src/tray.rs`
- `src/xray.rs`
- `src/selftest.rs`
- `src/sysproxy.rs`
- `src/state.rs`
- `src/crypto.rs`
- `src/logger.rs`
- `src/security.rs`
- `src/settings.rs`
- `src/vless.rs`

این‌ها مسیرهای کامپایل‌شده هستند؛ وجود مسیر، متن فایل را در اختیار نمی‌گذارد. فهرست crateهای ثالث جدا در `rust-crate-path-references.txt` است و نباید با ماژول‌های اختصاصی پروژه اشتباه گرفته شود.

## وابستگی‌های Rust قابل مشاهده

نسخه‌های قابل مشاهده در مسیرهای build/debug برای نمونه شامل `tauri 2.12.1`, `tauri-utils 2.10.1`, `tokio 1.53.2`, `reqwest 0.12.28`, `rustls 0.23.45`, `ring 0.17.14`, `serde 1.0.229`, `serde_json 1.0.151`, `windows 0.62.2`, `webview2-com 0.39.1` هستند. فهرست کامل در فایل هم‌نام است.

این فهرست از path strings/debug metadata آمده و **Cargo.lock یا manifest قطعی نیست**؛ dependency resolution نهایی را بدون lockfile نمی‌توان ثابت کرد.

## Importهای Windows

فایل `imports/IMPORTS-BY-DLL.md` importها را گروه‌بندی کرده است. خانواده‌های مهم:

- `kernel32`: process/thread/file/registry-independent primitives, `CreateProcessW`, debugger checks, mutexes, handles.
- `shell32`: `ShellExecuteExW`, `IsUserAnAdmin`, known-folder, tray integration.
- `advapi32`: Registry/security access.
- `crypt32`: DPAPI protect/unprotect.
- `wintrust`: trust/signature APIs.
- `iphlpapi`: IP/interface/routing information.
- `wininet`: Windows network APIs.
- `bcrypt`: system crypto primitives.
- `ntdll`: low-level file/device IO.

Import فقط وابستگی API را ثابت می‌کند؛ به‌تنهایی نمی‌گوید هر API در چه شرایطی صدا زده می‌شود.

## چیزهایی که پیدا نشد

- فایل‌های `.rs` و Cargo manifest/lock
- فایل `bepar_vpn.pdb`
- runtime settings/cache/config fileها
- subscription feed URLهای واقعی به‌شکل متن واضح
- کدهای backend قابل بازیابی و build مستقل
