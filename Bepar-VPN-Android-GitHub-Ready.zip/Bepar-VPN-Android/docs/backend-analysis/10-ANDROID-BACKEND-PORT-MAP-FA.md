# نگاشت Backend ویندوز به معماری Android

این سند طرح انتقال بر اساس رفتار مشاهده‌شده است؛ کد آماده و تست‌شده Android نیست.

## اجزای پیشنهادی

| ماژول اصلی Windows (شواهد مسیر) | مسئولیت مشاهده‌شده/استنباطی | جایگزین Android |
|---|---|---|
| `commands.rs` | IPC فرمان‌ها | Kotlin use-case/API layer؛ بدون Tauri |
| `state.rs` | وضعیت مرکزی اتصال/UI | StateFlow immutable state holder |
| `settings.rs` | settings persistence/defaults/migration | DataStore + typed settings |
| `source.rs` | fetch subscription/cache/etag | Repository + OkHttp/HTTP client |
| `pool.rs` | parse/dedup/test/rank/quality stages | ConfigPool pipeline/coroutines |
| `vless.rs` | parse URI/protocol config | Parser module with strict validation/tests |
| `tester.rs` | ping/quality/performance/traffic gates | network test layer executed through tunnel context |
| `geoip.rs` | GeoIP database parsing/country mapping | binary protobuf reader or convert supplied data to compact runtime indexes |
| `xraycfg.rs` | generate/validate Xray JSON | Xray configuration generator with golden tests |
| `xray.rs` | start/stop/monitor Xray process/API/stats | Android-compatible Xray core via supported Android packaging/JNI or service runner |
| `sysproxy.rs` | Windows system proxy change/restore | not equivalent; Android uses VpnService route capture, no global system proxy API equivalent |
| `tray.rs` | system tray / window hide | Android foreground notification and app navigation |
| `intercept.rs` | TLS interception detection | Android-compatible trust/proxy diagnostics; do not claim exact parity with Windows registry/process scan |
| `security.rs` | integrity/security lock | Android app integrity strategy + security state; platform APIs differ |
| `crypto.rs` | local encrypted storage | Android Keystore + AEAD with versioned envelope |
| `logger.rs` | redaction/logging | structured logging with secrets redacted before serialization |
| `selftest.rs` | startup/internal assertions | JVM/unit/instrumentation tests plus engine smoke test |

## Non-portable Windows dependencies

- `Bepar VPN.exe` itself is x86-64 Windows PE, not Android ELF/DEX.
- `xray.exe` is also Windows/amd64; Go build metadata confirms `GOOS=windows`, `GOARCH=amd64`, `CGO_ENABLED=0`.
- Wintun and `wintun.dll` are Windows driver/library; not Android tun driver.
- Windows registry, UAC/admin relaunch, tray, system proxy management, Job Object process tree cleanup, DPAPI are non-portable.

## Android VPN architecture

- A user-consented Android `VpnService` is required to create the local TUN interface and route selected traffic.
- Use an Android-compatible engine build for target ABIs (at minimum arm64-v8a; optional armeabi-v7a/x86_64 only if deliberately supported). Do not package `xray.exe`.
- Foreground-service lifecycle, notification channel, service restart, battery restrictions, Android 13+ notification permission, VPN consent and always-on settings must be handled explicitly.
- Engine must bind local SOCKS/HTTP or accept TUN file descriptor depending on chosen integration. The precise current Bepar Xray config is not fully recovered, so initial implementation should include config golden tests and runtime instrumentation before UI reports connected.
- Per-app routing, DNS mode, IPv6, bypass/allow lists, MTU, route inclusions/exclusions, and kill-switch semantics must be deliberately specified; Windows system proxy logic cannot be copied.

## Porting checklist

1. Recover original Rust source/PDB/runtime feed definitions if possible.
2. Formalize protocol parser models from recovered samples and strings.
3. Reimplement the IPC contract as Kotlin domain APIs.
4. Port settings with versioned schema/migrations.
5. Convert/import geoip/geosite data and test record counts.
6. Build or adopt a supported Android Xray core integration with matching protocol capabilities.
7. Implement VpnService/TUN and foreground lifecycle.
8. Reproduce source fetch caching/ETag/dedup/test pipeline.
9. Implement honest connection gate: Xray process ready + handshake + traffic confirmation, not just a ping.
10. Add parser, pool, config golden, lifecycle, failover, and leak-prevention tests.
11. Verify on real Android devices and networks; APK build alone is insufficient.
