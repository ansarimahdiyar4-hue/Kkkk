# کالبدشکافی عمیق رابط اصلی Bepar VPN 2.0

> این گزارش از HTML، JavaScript، CSS و منابعی تهیه شده که به‌صورت مستقیم از streamهای Brotli جاسازی‌شده در `Bepar VPN.exe` بازیابی شده‌اند. فایل‌های متنی اصلی در پوشه `07-original-frontend-source/Bepar-Original-Frontend` قرار دارند. این یک بازسازی تصویری نیست؛ این‌ها فایل‌های واقعی frontend استخراج‌شده‌اند.

## ۱) نتیجه استخراج واقعی frontend

| نوع | تعداد | توضیح |
|---|---:|---|
| HTML | ۱ | `index.html`، سند واقعی UI |
| JavaScript | ۲ | `app.js` منطق UI و `worldmask.js` نقشه/ماسک کره |
| CSS | ۱ | `styles.css` استایل اصلی رابط |
| SVG | ۲۵۷ | پرچم‌های کشور/قلمرو |
| PNG | ۲ | `bepar.png` و `telegram.png` |
| WOFF2 | ۳ | Inter Latin، Inter Latin Extended و Estedad Variable |
| **جمع کل** | **۲۶۶ فایل** | بدون احتساب فایل manifest |

همه ۲۵۷ فایل SVG با XML parser بررسی شدند. هر دو PNG با Pillow باز و verify شدند. فونت‌های WOFF2 با fontTools خوانده شدند. مسیرهای فایل HTML و CSS نیز از نظر وجود فایل مقصد بررسی شدند.

## ۲) ساختار صفحه‌ها و حالت‌ها

### شروع و محافظت اولیه
- Splash تمام‌صفحه با لوگوی Bepar، حلقه چرخان، نام محصول و متن وضعیت.
- Splash دارای خروج نرم opacity/visibility و failsafe زمانی ۸٫۸ ثانیه‌ای است.
- پیش از ورود به برنامه، صفحه Security Warning می‌تواند برنامه‌های debugger یا TLS/HTTP interception را گزارش کند؛ موارد نمونه در متن اصلی شامل Fiddler، Charles، mitmproxy، Burp و HTTP debugger است.
- بخش هشدار دارای نام برنامه شناسایی‌شده، شواهد، راهنمای حذف، Check again و Close Bepar است.
- صفحه Lock در رخداد `security_lock` نشان داده می‌شود؛ طبق منطق UI، اتصال قطع و UI به حالت disconnected بازمی‌گردد. پاک شدن قفل با event جداگانه به UI اطلاع داده می‌شود.

### انتخاب زبان و شرایط استفاده
- صفحه انتخاب زبان دو گزینه فارسی و انگلیسی دارد.
- سند شرایط و حریم خصوصی پیش از ادامه نمایش داده می‌شود؛ checkbox موافقت و دکمه‌های Decline/Continue وجود دارند.
- متن شرایط ۹ بخش دارد: معرفی، جمع‌آوری داده، منابع سرورها، سرورهای ثالث، نبود ناشناسی مطلق، استفاده قانونی، اجزای Bepar، مهندسی معکوس و جعل منبع/کانفیگ مخرب.

### راه‌اندازی اولیه (Onboarding)
- گام اول: انتخاب یک منبع پیکربندی؛ متن صریح می‌گوید تا تأیید انتخاب، چیزی دانلود نمی‌شود.
- گام دوم: انتخاب حالت Automatic یا Manual.
- Automatic سرورهای بارگذاری‌شده را رتبه‌بندی می‌کند و هنگام Connect بهترین سرور را انتخاب می‌کند.
- Manual انتخاب یک سرور مشخص را از کاربر می‌خواهد و تا فشردن Connect چیزی وصل نمی‌شود.
- گام سوم: دریافت کانفیگ‌ها با progress؛ در صورت خطا، Choose another source و Retry نمایش داده می‌شود.
- onboarding تنها پس از دریافت pool غیرخالی کامل می‌شود؛ این شرط در منطق frontend مشخص است.

### صفحه Home
- عنوان/نوار بالایی Bepar VPN و کنترل‌های Hide/Close مخصوص پنجره دسکتاپ.
- انتخاب‌گر سرور که Automatic یا نام سرور انتخابی را نشان می‌دهد.
- بنر وضعیت دریافت سرورها و درصد پیشرفت.
- Canvas کره زمین متحرک با land mask یک درجه‌ای.
- دکمه اصلی Power با حالت‌های خاموش، روشن، busy و cancel.
- نشانگر درصد/پیشرفت اتصال و متن وضعیت.
- دکمه latency با واحد ms؛ در وضعیت اتصال فعال می‌شود و قابلیت اندازه‌گیری latency دارد.
- کارت جزئیات اتصال پس از اتصال: نام و پرچم سرور، مدت اتصال، سرعت لحظه‌ای دانلود/آپلود، حجم کل دانلود/آپلود، وضعیت Online، تعداد تلاش‌ها و latency.
- دکمه Telegram و کارت/اکشن کپی شناسه کانال.

### پنجره انتخاب سرور
- Bottom sheet با backdrop، عنوان Select Server و شمارنده تعداد سرورها.
- گزینه Automatic در ابتدای فهرست.
- گروه‌بندی سرورها بر اساس کشور، همراه پرچم SVG.
- نام سرور، برچسب‌های تکمیلی و ping.
- Search by name/country/IP/host.
- Ping Test برای هر سرور و Test All Ping برای کل pool.
- علامت انتخاب‌شده و حفظ scroll position پس از رندر مجدد.
- انتخاب Automatic حالت را به auto و انتخاب سرور واقعی را به manual تغییر می‌دهد.
- تغییر سرور در حین اتصال در UI ثبت می‌شود، اما متن توضیح می‌دهد این انتخاب برای اتصال بعدی استفاده خواهد شد.

### Settings و زیرصفحه‌ها
- Server updates: Refresh servers و آمار pool مانند تعداد تست‌شده و کشورها/زمان واکشی.
- Config source: انتخاب منبع از metadata برگشتی backend؛ frontend نام خام upstream را در UI ماسک کرده و به برچسب ترتیبی Config Peer 1..7 یا «کانفیگ بپر ۱..۷» تبدیل می‌کند.
- Security: صفحه مستقل وضعیت حفاظت و تنظیمات قابل تغییر.
- Appearance: Dark/Light و انتخاب Accent از نوار گرادیان طیفی، به‌علاوه دو انتهای سفید و مشکی.
- Language: English و فارسی.
- DNS: System default، Cloudflare 1.1.1.1، Google 8.8.8.8، Quad9 9.9.9.9 و Custom.
- Custom DNS ورودی چند resolver با جداکننده فاصله/کاما/semicolon می‌پذیرد؛ اعتبارسنجی IP یا HTTPS resolver در frontend وجود دارد.
- TUN Mode به‌صورت toggle در صفحه تنظیمات اصلی دیده می‌شود و وضعیت آمادگی/خطا را نشان می‌دهد.

### Security detail
- Encrypt Connection Data: متن UI توضیح می‌دهد داده‌های ذخیره‌شده با AES-256-GCM seal می‌شوند و کلید با Windows DPAPI محافظت شده؛ UI آن را گزینه خاموش/روشن کاربر قرار نمی‌دهد و encryption را اجباری می‌داند.
- Cache Protection: محافظت خودکار از لیست سرورها و اندازه‌گیری‌های ذخیره‌شده.
- App Integrity Check: مقایسه fingerprint فایل اجرایی در شروع.
- Secure Update Verification: UI صریحاً می‌گوید بررسی امضای انتشار فقط زمانی ممکن است که build کانال update امضاشده داشته باشد؛ نسخه فعلی می‌تواند Unsigned / unavailable گزارش شود.
- Sensitive Log Protection: حذف لینک‌ها و credentialهای حساس از log.
- Secure Clipboard: پاک کردن مقدار کپی‌شده Bepar پس از ۳۰ ثانیه فقط اگر clipboard هنوز همان مقدار باشد.
- Network Leak Protection: در توضیح UI آمده اگر tunnel بیفتد، system proxy به پورت بسته هدایت می‌شود تا رفتار fail-closed داشته باشد؛ این توضیح مربوط به پیاده‌سازی ویندوز است و نباید بدون port واقعی به Android تعمیم داده شود.

### About
- نام، نسخه 2.0.0، نشان‌های Free / Privacy first / Lightweight.
- بخش سرورهای ثالث، آنچه محافظت می‌شود و محدودیت‌های VPN.
- شناسه Telegram به شکل `@Bepar_VPN` و دکمه Copy.
- متن copyright سال 2026.

## ۳) منابع و داده‌های گرافیکی
- `bepar.png`: تصویر PNG اصلی که Splash، لوگو و برخی کارت‌ها به آن ارجاع می‌دهند.
- `telegram.png`: تصویر دکمه/اکشن Telegram.
- `flags/*.svg`: ۲۵۷ پرچم اصلی که براساس کد کشور در سرور لیست می‌شوند. فایل‌های SVG خام هستند و به PNG تبدیل نشده‌اند.
- فونت Inter در دو subset لاتین و لاتین گسترده؛ هر دو با محور متغیر وزن 100 تا 900.
- فونت Estedad Variable با محور وزن 100 تا 900 برای فارسی/عربی.
- `worldmask.js`: ماسک land یک درجه‌ای جهان (۳۶۰ ستون در ۱۸۰ ردیف) برای ترسیم کره؛ متن فایل منبع می‌گوید bit set=land و ترتیب row-major از طول جغرافیایی -۱۸۰ و عرض +۹۰ است.
- فایل‌های طراحی Figma/Sketch، Lottie مستقل، فایل After Effects یا ویدیو در ورودی مشاهده نشد؛ انیمیشن‌های اصلی در CSS/JS پیاده شده‌اند.

## ۴) ریزه‌کاری‌های انیمیشن و حرکت

انیمیشن‌های keyframe استخراج‌شده از CSS:
` splashSpin`, `splashFailsafe`, `uiEnter`, `dockIn`, `spin`, `cardIn`, `pulse`, `pop`, `up`, `fadeIn`, `down`, `fadeOut`, `snackIn`, `pageIn`, `pingSpin`, `riseIn`, `subIn`.

نمونه زمان‌های تصریح‌شده در CSS/JS:
- حلقه Splash: چرخش پیوسته ۱٫۴۳ ثانیه‌ای.
- ورود UI: حدود ۰٫۶۰۵ ثانیه.
- ورود dock: حدود ۰٫۴۱۸ ثانیه.
- انیمیشن ورود کارت: ۰٫۵ ثانیه.
- pulse glow: چرخه ۲٫۲ ثانیه‌ای.
- چرخش spinner عمومی: ۰٫۸۸ ثانیه؛ power loader: حدود ۰٫۹۹ ثانیه.
- ورود Bottom sheet: backdrop fade حدود ۰٫۱۹۸ ثانیه و حرکت sheet حدود ۰٫۳۳ ثانیه؛ خروج با mirror slide-down.
- snackbar: حدود ۰٫۲۴۲ ثانیه.
- page enter: حدود ۰٫۳۰۸ ثانیه.
- card rise-in: حدود ۰٫۳۷۴ ثانیه.
- subscreen enter: حدود ۰٫۲۶۴ ثانیه.
- flag fade: حدود ۰٫۲۴۲ ثانیه.
- row entrance: حدود ۰٫۱۷۶ ثانیه.
- ping spinner: حدود ۰٫۷۷ ثانیه.
- globe: هنگام قطع تقریباً ۱٫۱ درجه بر ثانیه و هنگام اتصال ۷٫۵ درجه بر ثانیه؛ draw rate حداکثر تقریباً ۳۰fps.
- CSS media query برای `prefers-reduced-motion: reduce` وجود دارد.

## ۵) جزئیات رفتار و مدیریت وضعیت در app.js
- frontend دارای توابعی برای state rendering، ترجمه، theme/accent، server filtering/sorting، ping، onboarding، connection progress، navigation، DNS، globe، security، clipboard، settings و boot است.
- دو locale داخل کد وجود دارند: en و fa؛ پوشش هر کدام ۲۳۲ کلید یکتا (تکرار برخی کلیدها در object ثبت شده است).
- Tauri invoke commandهای فراخوانی‌شده از UI: `connect`, `disconnect`, `get_initial`, `get_pipeline_state`, `get_pool`, `get_sources`, `get_status`, `measure_delay`, `open_url`, `ping_all`, `ping_server`, `quit_app`, `refresh_pool`, `save_settings`, `security_recheck`, `security_status`, `select_server`, `startup_check`, `tun_preflight`, `tun_set`, `win_hide`.
- Tauri eventهای شنیده‌شده در UI شامل: `status`, `pool`, `pool_progress`, `pool_error`, `auto_rank`, `connect_progress`, `ping_result`, `ping_all_done`, `xray`, `security_lock`, `security_lock_cleared`, `settings` هستند.
- رویدادهای DOM شامل click/input/change/keydown/pointerdown/pointermove/pointerup/pointercancel/resize/focus/visibilitychange/error است.
- برای جلوگیری از re-render بی‌دلیل لیست سرورها، UI امضای server list را محاسبه می‌کند و render را فقط در صورت تغییر واقعی انجام می‌دهد.
- نتایج `Test All Ping` به‌صورت batch/coalesced رندر می‌شوند (timer حدود ۱۲۰ms) تا کل DOM در برابر هر نتیجه دوباره ساخته نشود.
- در زمان تغییر منبع، epoch درخواست pool افزایش می‌یابد تا پاسخ دیررس منبع قبلی جای لیست جدید را نگیرد.
- هنگام connect، UI قبل از round-trip فرمان IPC به حالت busy می‌رود و لمس دوباره در حالت connecting نقش cancel دارد.
- هنگام برگشت پنجره از حالت پس‌زمینه، backend state دوباره sync می‌شود چون WebView ممکن است timer/event را throttle کرده باشد.
- لیست سرورها با country، latency، نام، host/IP و protocol قابل جست‌وجو/مرتب‌سازی است؛ منطق دقیق بیشتر در فایل اصلی `app.js` حفظ شده است.

## ۶) سیستم طراحی (Design system)
- CSS شامل بیش از ۲۰۰ توکن selector class/id و ۴۷۹ بلوک selector در فایل اصلی است.
- تم dark: پس‌زمینه تقریباً مشکی `#000000`، سطوح فرعی `#0A0C0E`، متن `#F5F7FA`، muted `#8A919C`، رنگ خطر `#EF4444`، موفقیت `#22C55E`، هشدار `#F59E0B` و رنگ upload `#60A5FA`.
- تم light: پس‌زمینه سفید `#FFFFFF`، سطح دوم `#F1F3F7`، متن `#131A24`، muted `#525E6D`، danger `#DC2626`، success `#15803D`، warning `#B45309` و upload `#1D4ED8`.
- accent سفارشی مبتنی بر hue است و ink/foreground خودکار برای خوانایی روی تم روشن/تیره محاسبه می‌شود.
- در CSS اصلی فقط media query مخصوص کاهش حرکت سیستم وجود دارد؛ اندازه‌بندی اصلی بر پایه layout desktop/Tauri و اندازه پنجره است، بنابراین برای Android باید responsive/mobile layout جداگانه طراحی و تست شود.

## ۷) چه چیزهایی از فایل اجرایی به دست نمی‌آیند
- پروژه Rust قابل build (`Cargo.toml` و سورس کامل `src/*.rs`) از exe بازسازی نشده؛ تنها مسیرهای فایل source مثل `src/pool.rs`, `src/commands.rs`, `src/geoip.rs`, `src/source.rs`, `src/tester.rs`, `src/xraycfg.rs`, `src/tray.rs`, `src/xray.rs`, `src/selftest.rs`, `src/sysproxy.rs`, `src/vless.rs`, `src/settings.rs` به‌عنوان string hints موجودند.
- API/سرورهای واقعی feed و محتوای live configs به‌صورت source project یا دیتابیس کامل قابل استخراج نیستند.
- `xray.exe` داخل ورودی، PE ویندوز x86-64 است؛ روی Android قابل اجرا نیست. انتقال کامل VPN نیازمند جایگزینی backend با Android `VpnService`، مدیریت مجوز VPN، هسته Xray سازگار با ABI اندروید و پیاده‌سازی مجدد TUN/DNS/leak protection است.
- استخراج frontend به معنای استخراج منطق backend یا تایید عملکرد امنیتی آن نیست.

## ۸) نکته مهم درباره سازگاری پورت
`index.html`، `styles.css`، `app.js`، `worldmask.js` و دارایی‌های ریشه در این بسته با مسیرهای اصلی وب حفظ شده‌اند؛ فایل‌ها مستقیم در کنار هم قرار گرفته‌اند تا ارجاع‌های relative خراب نشوند. این سورس اصلی frontend دسکتاپ است، نه یک اپ اندرویدی آماده. هنگام پورت می‌توان از آن به عنوان مرجع رفتاری/دیداری دقیق استفاده کرد، اما shell دسکتاپ، نوار عنوان ویندوز، پنجره، Tauri IPC و رفتار Wintun/DPAPI باید با اجزای Android بازنویسی شوند.
