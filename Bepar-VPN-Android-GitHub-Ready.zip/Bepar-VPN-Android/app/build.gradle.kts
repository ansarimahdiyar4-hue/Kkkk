import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply {
    if (keystorePropsFile.exists()) {
        FileInputStream(keystorePropsFile).use { load(it) }
    }
}

fun signingValue(propKey: String, envKey: String): String? {
    val fromProp = keystoreProps.getProperty(propKey)?.trim()
    if (!fromProp.isNullOrEmpty()) return fromProp
    val fromEnv = System.getenv(envKey)?.trim()
    return if (!fromEnv.isNullOrEmpty()) fromEnv else null
}

val releaseStorePath = signingValue("storeFile", "BEPAR_KEYSTORE_PATH")
val releaseStorePassword = signingValue("storePassword", "BEPAR_KEYSTORE_PASSWORD")
val releaseKeyAlias = signingValue("keyAlias", "BEPAR_KEY_ALIAS")
val releaseKeyPassword = signingValue("keyPassword", "BEPAR_KEY_PASSWORD")
val hasReleaseSigning = !releaseStorePath.isNullOrEmpty() &&
    !releaseStorePassword.isNullOrEmpty() &&
    !releaseKeyAlias.isNullOrEmpty() &&
    !releaseKeyPassword.isNullOrEmpty() &&
    file(releaseStorePath).exists()

android {
    namespace = "com.bepar.vpn"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bepar.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Pin the release signing certificate's SHA-256 (hex, lowercase, no colons).
        // Leave empty for debug/unsigned builds — the check is skipped when empty.
        // After you generate your release keystore, fill this in via:
        //   keytool -list -v -keystore your.keystore -alias yourAlias | grep SHA256
        // (take the certificate fingerprint, not the keystore password) and pass it as
        // -PbeparPinnedSigSha256=<hex> or set BEPAR_PINNED_SIG_SHA256 in keystore.properties.
        val pinnedSig = signingValue("pinnedSigSha256", "BEPAR_PINNED_SIG_SHA256").orEmpty()
        buildConfigField("String", "PINNED_SIG_SHA256", "\"${pinnedSig.lowercase()}\"")
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStorePath!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            // Code shrinking + obfuscation (R8) and unused-resource stripping.
            // Raises the bar against decompiling/reverse-engineering the APK; see
            // proguard-rules.pro for the obfuscation rules.
            isMinifyEnabled = true
            isShrinkResources = true
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            ndk {
                debugSymbolLevel = "NONE"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    testOptions {
        unitTests.all {
            it.maxHeapSize = "384m"
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // ─── هستهٔ native تونل (sing-box / libbox) ───────────────────────────────
    // این فایل باید از طریق CI یا ساخت محلی تولید شود.
    // راهنما: app/libs/README.txt  و  .github/workflows/android.yml
    val libboxAar = file("libs/libbox.aar")
    if (!libboxAar.exists()) {
        logger.error(
            """
            |========================================================================
            |  libbox.aar پیدا نشد در app/libs/
            |  بدون این فایل پروژه کامپایل نمی‌شود (کلاس‌های io.nekohasekai.libbox).
            |  برای ساخت:
            |    1) GitHub Actions موجود در .github/workflows/android.yml را اجرا کنید
            |    2) یا دستورات محلی داخل app/libs/README.txt را دنبال کنید
            |========================================================================
            """.trimMargin()
        )
        throw GradleException(
            "Missing app/libs/libbox.aar — see app/libs/README.txt for build instructions"
        )
    }
    implementation(files(libboxAar))

    val composeBom = platform("androidx.compose:compose-bom:2025.04.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.2")
    implementation("androidx.compose.material:material-icons-extended")

    // Native SVG flag rendering from assets/flags/*.svg
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("org.json:json:20240303")
}
