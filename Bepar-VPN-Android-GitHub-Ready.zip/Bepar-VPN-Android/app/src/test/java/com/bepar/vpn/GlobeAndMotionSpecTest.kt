package com.bepar.vpn

import com.bepar.vpn.ui.components.GlobeMotionSpec
import com.bepar.vpn.ui.components.WorldMaskLoader
import org.junit.Assert.*
import org.junit.Test

class GlobeAndMotionSpecTest {

    @Test
    fun globeSpeedConstantsMatchOriginalCssJsSpec() {
        assertEquals(1.1f, GlobeMotionSpec.SPIN_DISCONNECTED_DEG_PER_SEC, 0.001f)
        assertEquals(7.5f, GlobeMotionSpec.SPIN_CONNECTED_DEG_PER_SEC, 0.001f)
        assertEquals(33L, GlobeMotionSpec.FRAME_STEP_MS)
    }

    @Test
    fun bitmaskDecoderHandlesEmptyGracefully() {
        val empty = WorldMaskLoader.decodeBase64Mask("")
        assertTrue(empty.isEmpty())
    }
}
