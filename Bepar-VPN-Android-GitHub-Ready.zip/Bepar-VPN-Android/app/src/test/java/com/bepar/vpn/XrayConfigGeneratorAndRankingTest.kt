package com.bepar.vpn

import com.bepar.vpn.backend.AllocatedPorts
import com.bepar.vpn.backend.ParsedNodeConfig
import com.bepar.vpn.backend.ServerTester
import com.bepar.vpn.backend.XrayConfigGenerator
import com.bepar.vpn.model.DnsProvider
import com.bepar.vpn.model.ServerItem
import org.junit.Assert.*
import org.junit.Test

class XrayConfigGeneratorAndRankingTest {

    @Test
    fun buildAndValidateXrayConfigUsesFreeNonZeroPortsAndNoInsecureTls() {
        val ports = XrayConfigGenerator.allocateFreePorts()
        assertTrue(ports.socksPort > 0 && ports.httpPort > 0 && ports.apiPort > 0)
        assertNotEquals(ports.socksPort, ports.httpPort)
        assertNotEquals(ports.socksPort, ports.apiPort)

        val node = ParsedNodeConfig(
            key = "test-1",
            rawUri = "vless://11111111-2222-3333-4444-555555555555@198.51.100.10:443?security=tls",
            protocol = "vless",
            host = "198.51.100.10",
            port = 443,
            credential = "11111111-2222-3333-4444-555555555555",
            network = "ws",
            security = "tls",
            sni = "vpn.example.com",
            fp = "chrome",
            path = "/vless"
        )

        val json = XrayConfigGenerator.buildConfig(
            node = node,
            ports = AllocatedPorts(10808, 10809, 10810),
            dnsProvider = DnsProvider.CLOUDFLARE,
            dnsCustom = "",
            tunMode = true
        )
        val errors = XrayConfigGenerator.validateGeneratedConfig(json)
        assertTrue("Expected zero validation errors, got: $errors", errors.isEmpty())
        assertTrue(json.has("inbounds"))
        assertTrue(json.has("outbounds"))
        assertTrue(json.has("routing"))
        assertTrue(json.has("stats"))
    }

    @Test
    fun autoRankPrioritizesReachableLowLatencyHighStabilityServers() {
        val ranked = ServerTester.autoRankServers(
            listOf(
                ServerItem("dead", "Dead", latencyMs = 50, reachable = false, stability = 1.0),
                ServerItem("slow", "Slow", latencyMs = 420, reachable = true, stability = 0.5),
                ServerItem("fast", "Fast", latencyMs = 110, reachable = true, stability = 0.9)
            )
        )
        assertEquals(listOf("fast", "slow", "dead"), ranked.map { it.key })
    }
}
