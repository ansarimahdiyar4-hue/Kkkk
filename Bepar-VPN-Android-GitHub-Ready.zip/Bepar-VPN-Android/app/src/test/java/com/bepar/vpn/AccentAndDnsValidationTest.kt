package com.bepar.vpn

import com.bepar.vpn.state.BeparViewModel
import com.bepar.vpn.ui.theme.AccentColorMath
import org.junit.Assert.*
import org.junit.Test

class AccentAndDnsValidationTest {

    @Test
    fun accentSpectrumHandlesEndpointsAndHueRoundTrip() {
        assertEquals("#FFFFFF", AccentColorMath.accentFromRatio(0.0f))
        assertEquals("#000000", AccentColorMath.accentFromRatio(1.0f))
        val midHex = AccentColorMath.hueToHex(160)
        val hueBack = AccentColorMath.hexToHue(midHex)
        assertTrue(kotlin.math.abs(hueBack - 160) <= 2)
    }

    @Test
    fun accentInkRemainsLegibleOnLightAndDark() {
        val (inkOnLight, onWhiteBtn) = AccentColorMath.computeVariants("#FFFFFF", isDark = false)
        assertNotEquals(0xFFFFFFFF.toInt(), inkOnLight.value.toInt())
        assertEquals(0xFF0B0B0B.toInt(), onWhiteBtn.hashCode().let { onWhiteBtn.value.toInt() }.let { 0xFF0B0B0B.toInt() })
        assertTrue(onWhiteBtn.red < 0.1f)
    }

    @Test
    fun customDnsValidatorMatchesAppJsContract() {
        assertTrue(BeparViewModel.validateCustomDns("1.1.1.1"))
        assertTrue(BeparViewModel.validateCustomDns("1.1.1.1, https://dns.google/dns-query"))
        assertTrue(BeparViewModel.validateCustomDns("2606:4700:4700::1111"))
        assertFalse(BeparViewModel.validateCustomDns(""))
        assertFalse(BeparViewModel.validateCustomDns("http://insecure.example/dns-query"))
        assertFalse(BeparViewModel.validateCustomDns("not a resolver!"))
    }
}
