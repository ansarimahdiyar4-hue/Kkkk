# بیلد و اتصال — Bepar VPN Android (هسته شامل شده)

## وضعیت
`app/libs/libbox.aar` (sing-box SDK 1.14.0) داخل پروژه است.
همهٔ ABIها: armeabi-v7a / arm64-v8a / x86 / x86_64

## ساخت APK
```bash
# نیاز: JDK 17 + Android SDK (compileSdk 35)
./gradlew assembleDebug
# خروجی: app/build/outputs/apk/debug/app-debug.apk
```

یا در Android Studio: Open project → Sync → Build APK.

## اتصال روی گوشی
1. APK را نصب کنید
2. اپ را باز کنید و مراحل اولیه را طی کنید
3. Connect را بزنید و مجوز VPN سیستم را تأیید کنید
4. منبع پیش‌فرض (سرورهای بپر / morpheus) از فید عمومی لیست را می‌گیرد و تونل را بالا می‌آورد

## اگر وصل نشد
- مجوز VPN داده شده باشد
- اینترنت برای دریافت لیست سرور برقرار باشد
- در لاگ اپ اگر `core_unavailable` دیدید، هسته لود نشده (نادر با این AAR)
- می‌توانید URL سابسکریپشن سفارشی هم تنظیم کنید

## منبع هسته
https://github.com/singbox-android/libbox/releases/tag/1.14.0
